package net.lidl.taf.apps.app1.layer1.Home.datamodel;

import com.google.gson.annotations.Expose;

/**
 * Data model definition, all teh variables should match exactly the application screen names and mappings object names. So it will be easier to map the datamodel with mappings
 */
public class model {

    @Expose
    public String url;

    @Expose
    public String pattern;
}
