package net.lidl.taf.apps.app1;

import net.lidl.taf.apps.app1.layer1.web;
import net.lidl.taf.core.InstanceManager;

/**meinung class creates an instance of all layers. Layers are high level definition of the application functionlity or business logic
 *
 */
public class meinung extends InstanceManager {

    /**
     * Creates instance of web that will contain n number of keywordgroups. keyword groups belong to this layer or high level business logic
     * @return instance of web class
     */
    public web ui() {
        return getInstance(web.class);
    }

}
