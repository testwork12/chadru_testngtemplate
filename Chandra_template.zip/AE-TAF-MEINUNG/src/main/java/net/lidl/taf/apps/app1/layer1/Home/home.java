package net.lidl.taf.apps.app1.layer1.Home;

import net.lidl.taf.apps.app1.layer1.Home.datamodel.model;
import net.lidl.taf.client.selenium.WebDriverClient;
import net.lidl.taf.client.selenium.WebLocator;
import net.lidl.taf.core.AutomationFrameworkException;
import net.lidl.taf.core.util.Sleeper;
import net.lidl.taf.core.util.Waiter;
import net.lidl.taf.reporting.Keyword;
import net.lidl.taf.reporting.logger.Report;

/**
 * This is a generic keyword generic class that will contain tiny re usable modules of keywords and directly interact with application via automation tool. The modules of this
 * class should only be used in keyword group business logic class. Should not be used directly in the test cases.
 */
public class home {

    private final WebDriverClient client;
    private final Mappings Mappings;
    /**
     * Constructor to pass the automation tool client
     * @param client definition of client
     */
    public home(WebDriverClient client){
        this.client = client;
        this.Mappings = new Mappings();
    }
    /**
     * Definition of kw1
     */
   /* @Keyword()
    public void login_old(model model){
      /*
        client.autoFrameSelect(WebLocator.xpath("//span[@role='combobox']"),10);
        //client.element(WebLocator.xpath("//span[contains(@class,'select2 select2-container')]")).scrollintoview();
        for (int i = 0; i < 5; i++) {
            client.element(WebLocator.tagName("b")).scrollintoview();
            client.element(WebLocator.tagName("b")).click();
            if( client.isPresent(WebLocator.className("select2-search__field"),2)){
               break;
           }
        }
        client.element(WebLocator.className("select2-search__field")).setText(model.pattern);
        int count;
        Sleeper.silentSleep(2000);

        count = client.elements(WebLocator.xpath("(//li[contains(@class,'select2-results__option')])")).count();
        ArrayList result = new ArrayList();
        for (int i = 1; i <= count; i++) {
            if(i==1){
                client.element(WebLocator.xpath("(//li[contains(@class,'select2-results__option')])[" + i + "]")).scrollintoview();
            }
            result.add(client.element(WebLocator.xpath("(//li[contains(@class,'select2-results__option')])[" + i + "]")).getText());
        }
        Report.addFile(Status.INFO, new File(FileUtil.createFile4mObject(result, "test")).toPath(),model.pattern);
    }*/

    @Keyword()
    public void login(model model){

        Report.info("Starten", "Aufruf URL " + model.url + " - " + client.go(model.url),true);
        if(client.isPresent(Mappings.Accept_cookies_btn,5)){
            client.element(Mappings.Accept_cookies_btn,5).click();
            Report.info("Cookies", "accepted",false);
        }
        client.window().maximize();
        Sleeper.silentSleep(2000);
    }

    @Keyword()
    public boolean enter_store_id(model model){
        if(!client.autoFrameSelect(Mappings.IFRAME_Next_btn,20)){
            throw new AutomationFrameworkException("Page was not loaded correctly");
        }
        client.element(Mappings.Question_Text_lbl).scrollintoview();

        for (int i = 0; i < 5; i++) {
            client.element(Mappings.Search_4_Store_Open_btn).click();
            if( client.isPresent(Mappings.Search_4_Store_Input_txt,2)){
                break;
            }
        }
        client.element(Mappings.Search_4_Store_Input_txt).click();
        client.element(Mappings.Search_4_Store_Input_txt).setText(model.pattern);
        Sleeper.silentSleep(2000);
        String content= "";
        if(client.isPresent(Mappings.Search_4_Store_Result_List_Entry_lbl.replace("$INDEX$","[1]"),5)){
            content = client.element(Mappings.Search_4_Store_Result_List_Entry_lbl.replace("$INDEX$","[1]")).getText();
        }
        if(content.equalsIgnoreCase("No results found")){
            Report.info("No entry", "For the key: " + model.pattern + " no results found",true);
        }else{
            int count = client.elements(Mappings.Search_4_Store_Result_List_Entry_lbl.replace("$INDEX$","")).count();
            Report.info("Entry found", "For the key: " + model.pattern + " " + count + " entries found --> select the first",true);
            client.element(Mappings.Search_4_Store_Result_List_Entry_lbl.replace("$INDEX$","[1]")).click();
        }
        boolean error = false;
        client.element(Mappings.IFRAME_Next_btn).click();
        if(!client.isPresent(Mappings.Select_Age_List,5)){ //check element on next page
            error = true;
            Report.info("Error Msg", "found msg: " + client.element(Mappings.Check_4_Error_Msg_lbl).getText(),true);
        }
        client.switchToDefaultFrame();
        return error;
    }
    @Keyword()
    public void open_links_in_search_frame(){
        String text;
        if(!client.autoFrameSelect(Mappings.IFRAME_Next_btn,20)){
            throw new AutomationFrameworkException("Frame not found");
        }
        client.element(Mappings.Question_Text_lbl).scrollintoview();
        int count =client.elements(Mappings.Links_in_Search_4_Store_frame.replace("$INDEX$","")).count();
        WebLocator link;
        for (int i = 1; i <= count ; i++) {
            link = WebLocator.xpath("(//a[contains(@target,'_blank')])[" + i + "]");
            if(client.element(link).isDisplayed(2)) {
                text = client.element(link).getText();
                client.element(link).click();
                Sleeper.silentSleep(1000);
                int _new = client.getWindowHandles().size();
                if(_new == 2) {
                    client.switchTo().window(client.getWindowHandles().get(1));
                    Report.info("Paged opened", "Expected:  " + text + " found: " + client.element(WebLocator.tagName("h1")).getText(),true);
                    client.window().close();;
                    client.autoFrameSelect(Mappings.IFRAME_Next_btn,10);
                }
            }
        }
    }
    @Keyword()
    public boolean select_age(int index){
        Report.info("Select index " + index, "",true);
        client.autoFrameSelect(Mappings.IFRAME_Next_btn,10);
        client.element(Mappings.Question_Text_lbl).scrollintoview();
        client.element(Mappings.Select_Age_List).selectByIndex(index);
        boolean error = false;
        client.element(Mappings.IFRAME_Next_btn).click();
        Sleeper.silentSleep(1000);
        client.autoFrameSelect(Mappings.IFRAME_Next_btn,10);
        if(!client.isPresent(Mappings.Question_Rate_Start_img,5)){
            error = true;
            Report.info("Error Msg", "found msg: " + client.element(Mappings.Check_4_Error_Msg_lbl).getText(),true);
        }
        client.switchToDefaultFrame();
        return error;
    }

    @Keyword()
    public boolean answer_question(Integer index){
        client.autoFrameSelect(Mappings.IFRAME_Next_btn,10);
        client.element(Mappings.Question_Text_lbl).scrollintoview();
        String text = client.element(Mappings.Question_Text_lbl).getAttribute("innerText");
        if(index >0) {
            client.elements(Mappings.Question_Rate_Start_img).get(index - 1).hover();
        }
        boolean error = false;
        client.element(Mappings.IFRAME_Next_btn).click();
        if(client.isPresent(WebLocator.tagName("Q1_2"),5)){
            error = true;
            Report.info("Error Msg", "found msg: " + client.element(Mappings.Check_4_Error_Msg_lbl).getText(),true);
        }
        client.switchToDefaultFrame();
        return error;
    }

    @Keyword()
    public boolean answer_question_textarea(String content){
        client.autoFrameSelect(Mappings.IFRAME_Next_btn,10);
        client.element(Mappings.Question_Text_lbl).scrollintoview();
        String text = client.element(Mappings.Question_Text_lbl).getAttribute("innerText");
        boolean error = false;

        client.element(WebLocator.tagName("Q1_2")).click();
        client.element(WebLocator.tagName("Q1_2")).setText(content);

        client.element(Mappings.IFRAME_Next_btn).click();
        if(client.isPresent(WebLocator.tagName("Q1_2"),5)){
            error = true;
            Report.info("Error Msg", "found msg: " + client.element(Mappings.Check_4_Error_Msg_lbl).getText(),true);
        }
        client.switchToDefaultFrame();
        return error;
    }


}
