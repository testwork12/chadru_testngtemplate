package net.lidl.taf.apps;

import net.lidl.taf.apps.app1.meinung;
import net.lidl.taf.core.InstanceManager;

/**
 * This class is to instantiate the main apps class that would hold the separate applications instances involve in this project. Here meinung and app2 means two different applications. Ex meinung - mobile application
 * app2 - web application
 */
public class TemplateApps extends InstanceManager {

    /**
     * Instantiates application 1
     * @return instance of meinung class
     */
    public meinung meinung(){
        return getInstance(meinung.class);
    }

}