package net.lidl.taf.apps.app1.layer1.Home;

import net.lidl.taf.apps.app1.layer1.GlobalMappings;
import net.lidl.taf.client.selenium.WebLocator;

/**
 * All the mappings object should be non static so that if required at runtime we can append
 * any common variable / prefix. All the mappings object should exactly match the screen component name. Here objectID_txt must present in the application screen.
 * If that screen requires some other operations please specify in variable declaration
 */
public class Mappings extends GlobalMappings {


    public WebLocator Accept_cookies_btn = WebLocator.xpath("//a[@class='btn']");
    public WebLocator Search_4_Store_cbo = WebLocator.xpath("//span[@role='combobox']");
    public WebLocator Search_4_Store_Open_btn = WebLocator.tagName("b");
    public WebLocator Search_4_Store_Input_txt = WebLocator.className("select2-search__field");
    public WebLocator Search_4_Store_Result_List_Entry_lbl = WebLocator.xpath("(//li[contains(@class,'select2-results__option')])$INDEX$");
    public WebLocator Links_in_Search_4_Store_frame = WebLocator.xpath("(//a[contains(@target,'_blank')])$INDEX$");


    public WebLocator Select_Age_List = WebLocator.id("Alter");


    public WebLocator IFRAME_Next_btn = WebLocator.xpath("(//button[contains(@class,'nextButton')])");
    public WebLocator Check_4_Error_Msg_lbl =WebLocator.className("validationMessageText");


    public WebLocator Question_Text_lbl = WebLocator.className("questionText");

    public WebLocator Question_Rate_Start_img = WebLocator.xpath("//div[@id='Q1_stars']/img");


    /** optional parameter to init the objects
     *
     */
    public Mappings() {

    }
}
