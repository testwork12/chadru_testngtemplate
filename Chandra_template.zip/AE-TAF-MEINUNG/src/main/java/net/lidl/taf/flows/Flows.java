package net.lidl.taf.flows;

import net.lidl.taf.apps.TemplateApps;
import net.lidl.taf.core.InstanceManager;
import net.lidl.taf.flows.dummy.flow;

/**
 * This class creates instance flow class using templateapps. This is required if we have long sequence of keywordgroups and used multiple times in different keywords
 */
public class Flows extends InstanceManager {
    private TemplateApps apps;
    public Flows(TemplateApps apps) {
        this.apps = apps;
    }

    /**
     * Creating instance of flow
     * @return returns instance of flow class
     */
    public flow flow(){return getInstance(flow.class,apps);}
}
