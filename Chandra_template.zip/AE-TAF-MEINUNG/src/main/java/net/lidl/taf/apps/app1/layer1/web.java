package net.lidl.taf.apps.app1.layer1;

import net.lidl.taf.apps.app1.layer1.Home.home;
import net.lidl.taf.client.selenium.Browser;
import net.lidl.taf.client.selenium.WebDriverClient;
import net.lidl.taf.client.selenium.WebDriverClientFactory;
import net.lidl.taf.core.InstanceManager;
import net.lidl.taf.core.util.FileUtil;
import org.openqa.selenium.chrome.ChromeOptions;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * web class creates an instance of all keywordgroups. Keywordword groups are defined as group of keywords or reusable tiny modules. Keyword groups must contain only group of keywords,
 * some validation done with keywords. But no direct interaction with the application with automation tool is allowed here. This class also creates instance of automation tool.
 */
public class web extends InstanceManager {

    /*
    Variable declaration of the automation tool client
     */
    private WebDriverClient client;

    /**
     * Constructor to create the client with required parameters
     */
    public web(){
        if(client==null){
            ChromeOptions opt = new ChromeOptions();
            try {
                opt.addExtensions(FileUtil.exportResource("proxy.zip").toFile());
            } catch (IOException e) {
                e.printStackTrace();
            }
            client = WebDriverClientFactory.withBrowser(Browser.CHROME).create(false,false, opt);
        }
    }
    /**
     * Creates instance of home that will contain n number of keywords or reusable modules. keywords or reusable modules belong to this keywordgroup
     * @return instance of home class
     */
    public home home(){return getInstance(home.class,client);};
    /**
     * Creates instance of kwg2 that will contain n number of keywords or reusable modules. keywords or reusable modules belong to this keywordgroup
     * @return instance of kwg2 class
     */

    @Override
    public void cleanUp() {
        client.quit();
    }

    @Override
    public void emergencyCleanUp() {
        super.emergencyCleanUp();
        client.quit();
    }
}
