package net.lidl.taf.apps.app1.layer1;

/**
 * This class will hold the mappings object of the application. We need to keep only those mappings that are present in multiple pages
 * and not dependent on any other page component. Ex - signout in any web application. All the mappings object should be non static so that if required at runtime we can append
 * any common variable / prefix
 */
public class GlobalMappings {
}
