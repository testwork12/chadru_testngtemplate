package net.lidl.taf.tests;

import net.lidl.taf.apps.TemplateApps;
import net.lidl.taf.core.TestCaseBase;
import net.lidl.taf.flows.Flows;
import net.lidl.taf.reporting.testng.TestNGSuiteListener;
import net.lidl.taf.reporting.testng.TestNGTestListener;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;

import java.lang.reflect.Method;

/**
 * This is the base test case class that extends testcasebase from core and inherits the features. It defines the templateapps and flows app
 */
@Listeners({TestNGTestListener.class, TestNGSuiteListener.class})
public class TemplateTestCaseBase extends TestCaseBase {
    private Flows flows;
    private TemplateApps apps;

    /**
     * Method that will be executed before each method
     */
    @BeforeMethod(alwaysRun = true)
    public void setup(){
        apps = new TemplateApps();
        flows = new Flows(apps);
    }

    /**
     * Creating instance of templateapps
     * @return apps class instance
     */
    public TemplateApps apps() {
        return apps;
    }

    /**
     * Creating instance of flows
     * @return Flows class instance
     */
    public Flows flows(){
        return flows;
    }

    /**
     * Fow clean up after the automation completed call this function.
     * @param method definition default testNG
     * @param testResult definition default testNG
     */
    @AfterMethod(alwaysRun = true)
    public void tearDownElwisBase(ITestResult testResult, Method method) {
        triggerAppropriateCleanUps(testResult, apps(), flows());
    }
}
