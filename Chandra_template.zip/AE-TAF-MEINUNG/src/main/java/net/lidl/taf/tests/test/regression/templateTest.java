package net.lidl.taf.tests.test.regression;

import net.lidl.taf.apps.app1.layer1.Home.datamodel.model;
import net.lidl.taf.client.data.GenericDataProvider;
import net.lidl.taf.client.data.TAF_TEST;
import net.lidl.taf.tests.TESTGROUPS;
import net.lidl.taf.tests.TemplateTestCaseBase;
import org.testng.Assert;
import org.testng.annotations.Test;

public class templateTest extends TemplateTestCaseBase {
    /**
     * High level definition of the test
     */
   @TAF_TEST(dataproviderthreadcount = 1, internalDataRessource = "data/dummy.xlsx")
   @Test(groups = TESTGROUPS.FIRSTTEST, dataProviderClass = GenericDataProvider.class, dataProvider = "generic_provider")
    public void templateTest(model model){


       apps().meinung().ui().home().login(model);
       //wrong input
     //  Assert.assertTrue(apps().meinung().ui().home().enter_store_id(model));
       //navigate
      // apps().meinung().ui().home().open_links_in_search_frame();
       //correct input
      model.pattern="123";
       Assert.assertFalse(apps().meinung().ui().home().enter_store_id(model));
       //navigate
       //apps().meinung().ui().home().open_links_in_search_frame();
       //select no age entry
       Assert.assertTrue(apps().meinung().ui().home().select_age(0));

       //select age entry
       Assert.assertFalse(apps().meinung().ui().home().select_age(3));
       //navigate
       apps().meinung().ui().home().open_links_in_search_frame();

       //no rating of question
       Assert.assertTrue(apps().meinung().ui().home().answer_question(0));
       //rating of question 2
       Assert.assertFalse(apps().meinung().ui().home().answer_question(2));
       //navigate
       apps().meinung().ui().home().open_links_in_search_frame();
        //should be an error
       Assert.assertTrue(apps().meinung().ui().home().answer_question_textarea("Guten Tag"));
        //fill in textarea
       Assert.assertFalse(apps().meinung().ui().home().answer_question_textarea("Guten Tag"));
       //navigate
       apps().meinung().ui().home().open_links_in_search_frame();

       //no rating of question
       Assert.assertTrue(apps().meinung().ui().home().answer_question(0));
       //rating of question 2
       Assert.assertFalse(apps().meinung().ui().home().answer_question(4));//line 20
       //navigate
       apps().meinung().ui().home().open_links_in_search_frame();


   }
}
