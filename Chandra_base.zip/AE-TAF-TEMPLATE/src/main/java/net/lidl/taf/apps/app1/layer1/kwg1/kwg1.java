package net.lidl.taf.apps.app1.layer1.kwg1;

import net.lidl.taf.apps.app1.layer1.kwg1.datamodel.kw1DM;
import net.lidl.taf.client.selenium.WebDriverClient;
import net.lidl.taf.reporting.Keyword;
/**
 * This class contains the keyword groups that can be directly used in the test cases
 */
public class kwg1 {
    private final WebDriverClient client;
    private final Mappings Mappings;
    private kwg1generic kwg1generic;

    /**
     * Constructor to pass the automation tool client, mappings and generic class
     * @param client definition of webdriver client
     */
    public kwg1(WebDriverClient client){
        this.client = client;
        this.Mappings = new Mappings();
        this.kwg1generic = new kwg1generic(client);
    }

    /**
     * Keyword group that are constructed with multiple tiny keywords defined in generic class
     * @param datamodel definition
     */
    @Keyword("TEST_Keyword")
    public void kw11(kw1DM datamodel){
        kwg1generic.kw1(datamodel);
    }
}
