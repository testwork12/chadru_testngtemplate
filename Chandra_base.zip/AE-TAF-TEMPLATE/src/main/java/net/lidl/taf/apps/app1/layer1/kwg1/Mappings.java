package net.lidl.taf.apps.app1.layer1.kwg1;

import net.lidl.taf.apps.app1.layer1.GlobalMappings;
import net.lidl.taf.client.selenium.WebLocator;

/**
 * All the mappings object should be non static so that if required at runtime we can append
 * any common variable / prefix. All the mappings object should exactly match the screen component name. Here objectID_txt must present in the application screen.
 * If that screen requires some other operations please specify in variable declaration
 */
public class Mappings extends GlobalMappings {


    public WebLocator objectId_txt = WebLocator.id("id_4_object");
    public WebLocator objectId_btn = WebLocator.id("id_4_btn");

    /** optional parameter to init the objects
     *
     */
    public Mappings() {

    }
}
