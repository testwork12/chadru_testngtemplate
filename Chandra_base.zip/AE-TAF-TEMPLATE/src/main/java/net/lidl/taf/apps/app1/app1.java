package net.lidl.taf.apps.app1;

import net.lidl.taf.apps.app1.layer1.layer1;
import net.lidl.taf.apps.app1.layer2.layer2;
import net.lidl.taf.core.InstanceManager;

/**app1 class creates an instance of all layers. Layers are high level definition of the application functionlity or business logic
 *
 */
public class app1 extends InstanceManager {

    /**
     * Creates instance of layer1 that will contain n number of keywordgroups. keyword groups belong to this layer or high level business logic
     * @return instance of layer1 class
     */
    public layer1 layer1() {
        return getInstance(layer1.class);
    }
    /**
     * Creates instance of layer2 that will contain n number of keywordgroups. keyword groups belong to this layer or high level business logic
     * @return instance of layer2 class
     */
    public layer2 layer2() {
        return getInstance(layer2.class);
    }

}
