package net.lidl.taf.apps.app1.layer1.kwg2.datamodel;

/**
 * Data model definition, all teh variables should match exactly the application screen names and mappings object names. So it will be easier to map the datamodel with mappings
 */
public class kw2_1DM {
    public String text;
}
