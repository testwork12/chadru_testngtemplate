package net.lidl.taf.apps.app2.layer1.kwg1.datamodel;
/**
 * Data model definition, all teh variables should match exactly the application screen names and mappings object names. So it will be easier to map the datamodel with mappings
 */
public class app2_kw1DM {
    public String text;
}
