package net.lidl.taf.apps.app2.layer1.kwg1;

import net.lidl.taf.apps.app2.layer1.kwg1.datamodel.app2_kw1DM;
import net.lidl.taf.client.ranorexlidl.TafRanorex;
import net.lidl.taf.reporting.Keyword;
/**
 * This is a generic keyword generic class that will contain tiny re usable modules of keywords and directly interact with application via automation tool. The modules of this
 * class should only be used in keyword group business logic class. Should not be used directly in the test cases.
 */
public class kwg1generic {

    private Mappings Mappings;
    private TafRanorex client;
    /**
     * Constructor to pass the automation tool client
     * @param client definition of client
     */
    public kwg1generic(TafRanorex client){
        this.client = client;
        this.Mappings = new Mappings();
    }
    /**
     * Definition of kw1
     * @param datamodel definition
     */
    @Keyword("TEST_Keyword_layer2")
    public void kw1(app2_kw1DM datamodel){
        client.waitForElement(Mappings.objectId_txt,40);
        client.click_clear_type(Mappings.objectId_txt, datamodel.text);
        client.click(Mappings.objectId_btn);
    }
}
