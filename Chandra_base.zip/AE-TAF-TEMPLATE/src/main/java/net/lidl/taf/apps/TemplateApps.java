package net.lidl.taf.apps;

import net.lidl.taf.apps.app1.app1;
import net.lidl.taf.apps.app2.app2;
import net.lidl.taf.core.InstanceManager;

/**
 * This class is to instantiate the main apps class that would hold the separate applications instances involve in this project. Here app1 and app2 means two different applications. Ex app1 - mobile application
 * app2 - web application
 */
public class TemplateApps extends InstanceManager {

    /**
     * Instantiates application 1
     * @return instance of app1 class
     */
    public app1 app1(){
        return getInstance(app1.class);
    }
    /**
     * Instantiates application 1
     * @return instance of app2 class
     */
    public app2 app2(){
        return getInstance(app2.class);
    }
}
