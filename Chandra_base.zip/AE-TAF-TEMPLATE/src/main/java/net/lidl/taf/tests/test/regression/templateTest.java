package net.lidl.taf.tests.test.regression;

import net.lidl.taf.apps.app1.layer1.kwg1.datamodel.kw1DM;
import net.lidl.taf.client.data.GenericDataProvider;
import net.lidl.taf.client.data.TAF_TEST;
import net.lidl.taf.tests.TESTGROUPS;
import net.lidl.taf.tests.TemplateTestCaseBase;
import org.testng.annotations.Test;

public class templateTest extends TemplateTestCaseBase {
    /**
     * High level definition of the test
     * @param model deifinition
     */
    @TAF_TEST(dataproviderthreadcount = 1,retries = 2, internalDataRessource = "dummy.xls")
    @Test(groups = TESTGROUPS.FIRSTTEST, dataProviderClass = GenericDataProvider.class)
    public void templateTest(kw1DM model){
        apps().app1().layer1().kwg1().kw11(model);
        flows().flow().dummyflow(model);

    }
}
