package net.lidl.taf.apps.app1.layer1.kwg2;

import net.lidl.taf.apps.app1.layer1.kwg2.datamodel.kw2_1DM;
import net.lidl.taf.apps.app1.layer1.kwg2.datamodel.kw2_2DM;
import net.lidl.taf.client.selenium.WebDriverClient;
import net.lidl.taf.reporting.Keyword;

/**
 * This class contains the keyword groups that can be directly used in the test cases
 */
public class kwg2 {

    private final WebDriverClient client;
    private final Mappings Mappings;
    private kwg2generic kwg2generic;

    /**
     * Constructor to pass the automation tool client, mappings and generic class
     * @param client definition of client
     */
    public kwg2(WebDriverClient client){
        this.client = client;
        this.Mappings = new Mappings();
        this.kwg2generic = new kwg2generic(client);
    }

    /**
     * Keyword group that are constructed with multiple tiny keywords defined in generic class
     * @param datamodel definition
     * @param datamodel1 definition
     */
    @Keyword("TEST_Keyword")
    public void kw2(kw2_1DM datamodel, kw2_2DM datamodel1){
        kwg2generic.kw21(datamodel);
        kwg2generic.kw22(datamodel1);
    }
}
