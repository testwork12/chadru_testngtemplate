package net.lidl.taf.apps.app1.layer1;

import net.lidl.taf.apps.app1.layer1.kwg1.kwg1;
import net.lidl.taf.apps.app1.layer1.kwg2.kwg2;
import net.lidl.taf.client.selenium.Browser;
import net.lidl.taf.client.selenium.WebDriverClient;
import net.lidl.taf.client.selenium.WebDriverClientFactory;
import net.lidl.taf.core.InstanceManager;

/**
 * layer1 class creates an instance of all keywordgroups. Keywordword groups are defined as group of keywords or reusable tiny modules. Keyword groups must contain only group of keywords,
 * some validation done with keywords. But no direct interaction with the application with automation tool is allowed here. This class also creates instance of automation tool.
 */
public class layer1 extends InstanceManager {

    /*
    Variable declaration of the automation tool client
     */
    private WebDriverClient client;

    /**
     * Constructor to create the client with required parameters
     */
    public layer1(){
        if(client==null){
            client = WebDriverClientFactory.withBrowser(Browser.CHROME).create(false,false);
        }
    }
    /**
     * Creates instance of kwg1 that will contain n number of keywords or reusable modules. keywords or reusable modules belong to this keywordgroup
     * @return instance of kwg1 class
     */
    public kwg1 kwg1(){return getInstance(kwg1.class,client);};
    /**
     * Creates instance of kwg2 that will contain n number of keywords or reusable modules. keywords or reusable modules belong to this keywordgroup
     * @return instance of kwg2 class
     */
    public kwg2 kwg2(){return getInstance(kwg2.class,client);};

}
