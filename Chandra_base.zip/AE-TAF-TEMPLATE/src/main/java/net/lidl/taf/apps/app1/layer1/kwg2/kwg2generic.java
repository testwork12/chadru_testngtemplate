package net.lidl.taf.apps.app1.layer1.kwg2;

import net.lidl.taf.apps.app1.layer1.kwg2.datamodel.kw2_1DM;
import net.lidl.taf.apps.app1.layer1.kwg2.datamodel.kw2_2DM;
import net.lidl.taf.client.selenium.WebDriverClient;
import net.lidl.taf.reporting.Keyword;

/**
 * This is a generic keyword generic class that will contain tiny re usable modules of keywords and directly interact with application via automation tool. The modules of this
 * class should only be used in keyword group business logic class. Should not be used directly in the test cases.
 */
public class kwg2generic {

    private final WebDriverClient client;
    private final Mappings Mappings;

    /**
     * Constructor to pass the automation tool client
     * @param client definition of client
     */
    public kwg2generic(WebDriverClient client){
        this.client = client;
        this.Mappings = new Mappings();
    }

    /**
     * Definition of kw21
     * @param datamodel definition
     */
    @Keyword("Generic_Keyword")
    public void kw21(kw2_1DM datamodel){
        client.autoFrameSelect(Mappings.objectId_txt,40);
        client.element(Mappings.objectId_txt).setText(datamodel.text);
        client.element(Mappings.objectId_btn).click();
    }
    /**
     * Definition of kw22
     * @param datamodel definition
     */
    @Keyword("Generic_Keyword")
    public void kw22(kw2_2DM datamodel){
        client.autoFrameSelect(Mappings.objectId_txt,40);
        client.element(Mappings.objectId_txt).setText(datamodel.text);
        client.element(Mappings.objectId_btn).click();
    }

}
