package net.lidl.taf.flows.dummy;

import net.lidl.taf.apps.TemplateApps;
import net.lidl.taf.apps.app1.layer1.kwg1.datamodel.kw1DM;
import net.lidl.taf.apps.app2.layer1.kwg1.datamodel.app2_kw1DM;

/**
 * This class holds the reusable components frm different applications or different layers
 */
public class flow {

    private TemplateApps apps;

    /**
     * Constructor for flow class taking parameter template apps to accomodate flows from different applciations
     * @param apps definition of apps
     */
    public flow(TemplateApps apps){
        this.apps = apps;
    }

    /**
     * Definition of dummyflow that contains reusable module to be used in multiple test cases. Same sequence of flow ( multiple layer or multiple apps are considered )
     * @param kw1_model definition
     */
    public void dummyflow(kw1DM kw1_model){
        apps.app1().layer1().kwg1().kw11(kw1_model);
        app2_kw1DM model_2 = new app2_kw1DM();
        model_2.text = kw1_model.text;
        apps.app2().layer1().kwg1().kw1(model_2);
    }
}
