package net.lidl.taf.apps.app1.layer2.kwg1;

import net.lidl.taf.apps.app2.layer1.GlobalMappings;

public class Mappings extends GlobalMappings {
}
