package net.lidl.taf.apps.app2.layer1.kwg1;

import net.lidl.taf.apps.app2.layer1.GlobalMappings;
/**
 * All the mappings object should be non static so that if required at runtime we can append
 * any common variable / prefix. All the mappings object should exactly match the screen component name. Here objectID_txt must present in the application screen.
 * If that screen requires some other operations please specify in variable declaration
 */
public class Mappings extends GlobalMappings {
    public String objectId_txt = "id_4_object";
    public String objectId_btn ="id_4_btn";

    /** optional parameter to init the objects
     *
     */
    public Mappings(){

    }

}
