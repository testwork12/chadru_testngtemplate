package net.lidl.taf.tests;

/**
 * This class file contains the definition of the test group ID. This ID is exactly same as your corresponding JIRA ID
 */
public class TESTGROUPS {
    public static final String FIRSTTEST = "MyFirstTest" ;
}
